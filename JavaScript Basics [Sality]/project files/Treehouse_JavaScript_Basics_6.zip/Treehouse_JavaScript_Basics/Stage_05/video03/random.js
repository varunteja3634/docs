function alertRandom() {
  var randomNumber = Math.floor( Math.random() * 6 ) + 1; 
  alert(randomNumber);
}