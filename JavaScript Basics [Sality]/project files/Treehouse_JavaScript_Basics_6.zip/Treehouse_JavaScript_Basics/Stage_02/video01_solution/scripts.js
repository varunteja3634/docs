var message = "Hello!";
alert(message);
message = "Welcome to JavaScript Basics";
alert(message);