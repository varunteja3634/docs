var dieRoll = Math.floor( Math.random() * 6 ) + 1;
alert('You rolled a ' + dieRoll);