alert("Hello from Treehouse");
document.write("<h1>Welcome to JavaScript Basics</h1>");
alert("Thanks for visiting.");