alert("Help me fix this program!");
alert(Can you get this message to appear?);
document.write("<h2>My first JavaScript program</h2>");
document.wrong("<p>I'm practicing 'debugging'.</p>");