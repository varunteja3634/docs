alert("hello there");
document.write("No it works!");
