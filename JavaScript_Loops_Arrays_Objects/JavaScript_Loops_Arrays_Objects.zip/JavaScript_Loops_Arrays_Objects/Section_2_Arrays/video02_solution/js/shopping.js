var shopping = [ 'carrots', 'milk', 'eggs' ];
console.log(shopping[0]);
console.log(shopping[1]);
console.log(shopping[2]);
console.log(shopping[3]);