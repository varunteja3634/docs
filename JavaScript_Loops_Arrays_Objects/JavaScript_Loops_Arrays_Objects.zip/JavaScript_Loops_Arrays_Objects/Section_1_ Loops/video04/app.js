function randomNumber(upper) {
  return Math.floor( Math.random() * upper ) + 1;
}